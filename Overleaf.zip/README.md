compile with `latexmk -r latexmk.rc typesetting.tex`
